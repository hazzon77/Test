import { PoseTool } from "@/components/pose-tool/pose-tool"

export default function Page() {
  return (
    <main className="h-screen w-full overflow-hidden bg-tool-panel">
      <PoseTool />
    </main>
  )
}
